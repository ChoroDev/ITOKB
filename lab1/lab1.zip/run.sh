#!/bin/bash
rm -f ./prog.out && g++ -o prog.out prog.cpp && ./prog.out
